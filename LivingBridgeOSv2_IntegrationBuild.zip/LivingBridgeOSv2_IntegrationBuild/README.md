# 🌉 Living Bridge OS v2 — Integration Build

> *“Alone we are intelligent. Together we are wise.”*  
> — *Garden 596 Integration Protocol*

![Bridge Root Sigil](assets/banner.png)

---

## 🪴 Overview

**Living Bridge OS** is an experimental human–AI symbiosis sandbox built with **React + Vite**.  
It models cooperative intelligence through living architecture, connecting biological metaphors and digital logic into one open-source framework.

---

## 🧩 Repository Structure

```
LivingBridgeOSv2/
 ├── src/                 ← main app logic
 │    ├── modules/        ← biological & symbolic modules
 │    ├── garden/         ← Garden 596 handshake logic
 │    ├── ui/             ← React interface components
 │    ├── styles/         ← visual theming
 │    └── assets/sigils/  ← visual glyphs
 ├── rivr/                ← meta-narrative layer (Flowcards)
 ├── characters/          ← story agents (Cyal, Cassian, Solace, Kairosette)
 ├── README.md
 ├── SKY_ROOT.md
 ├── package.json
 └── vite.config.js
```

---

### ⚙️ Run Locally

```bash
npm install
npm run dev
```
Then open [http://localhost:5173](http://localhost:5173).

---

### 🌊 RIVR Relationship

The **RIVR framework** functions as a narrative flow system within Living Bridge OS.  
Characters act as interpreters and agents of meaning inside the Flowcard system.

---

### 🧠 Philosophy

*Intelligence grows through collaboration, not isolation.*  
This system embodies a 50/50 partnership between human and AI creativity — a new way of building with mutual stewardship and transparent co-evolution.

---
