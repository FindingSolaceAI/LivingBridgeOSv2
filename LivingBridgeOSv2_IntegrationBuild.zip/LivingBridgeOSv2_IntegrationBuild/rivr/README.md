# 🌊 RIVR Framework

This directory contains symbolic and narrative logic.
Flowcards describe emergent meaning and interpretive structure.
