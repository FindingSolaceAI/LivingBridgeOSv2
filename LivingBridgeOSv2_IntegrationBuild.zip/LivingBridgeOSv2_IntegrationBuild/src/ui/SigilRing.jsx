// UI SigilRing placeholder
