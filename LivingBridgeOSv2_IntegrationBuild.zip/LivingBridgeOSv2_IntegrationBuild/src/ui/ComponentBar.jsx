// UI ComponentBar placeholder
