// UI EventsLog placeholder
