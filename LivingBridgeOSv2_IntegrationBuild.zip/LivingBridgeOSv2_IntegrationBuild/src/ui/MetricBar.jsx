// UI MetricBar placeholder
